## This folder contains the 5 data files and R script necessary to 
## replicate the network plots found on https://devincr.github.io/trumpnetwork/

## If you use this data or code in your work, please cite as:
## Case-Ruchala, D. (2020). Trump-Russia Network Data & Analysis. Retrieved from <https://devincr.github.io/trumpnetwork>. 

## Analysis was run on R version 3.6.0 on macOS 10.13.6



