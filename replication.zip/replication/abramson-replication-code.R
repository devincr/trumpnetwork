### Clear environment
rm(list = ls(all.names = TRUE))

##### DYNAMIC PLOTS ######

# install/load packages:
# install each using: install.packages("PackageName")
library(rio)
library(networkDynamic)
library(ndtv)
library(network)

# import data
nodesdyn <- import("nodes-dyn.csv")
linksdyn <- import("links-dyn.csv")

# create network object
net <- network(linksdyn, vertex.attr=nodesdyn, matrix.type="edgelist",
                loops=F, multiple=F, ignore.eval = F)

# add (transparent) colors for countries
mygray <- rgb(190, 190, 190, max = 255, alpha = 175, names = "mygray")
mycoral <- rgb(240, 128, 128, max = 255, alpha = 175, names = "mycoral")
myblue <- rgb(173, 216, 230, max = 255, alpha = 175, names = "myblue")
net %v% "col" <- c("#BEBEBEAF", "#F08080AF", "#ADD8E6AF")[net %v% "country.type"]

# set min/max period; one period beyond the max period (period = factored years)
minterm <- min(linksdyn$year)
maxterm <- max(linksdyn$year) + 1

# sets the nodes in the network as active throughout time 0 to max period
vs <- data.frame(onset = minterm, terminus= maxterm, vertex.id=1:(length(nodesdyn$id)))

# edges of the network appear one by one, each is active from their first activation til max time period
es <- data.frame(onset=linksdyn$year, terminus= maxterm,
                  head=as.matrix(net, matrix.type="edgelist")[,1],
                  tail=as.matrix(net, matrix.type="edgelist")[,2])

# create dynamic network
net.dyn <- networkDynamic(base.net=net, edge.spells=es, vertex.spells=vs)

# compute animation and plot
compute.animation(net.dyn, animation.mode = "kamadakawai",
                  slice.par=list(start= minterm, end= maxterm, interval=1,
                                 aggregate.dur=1, rule='all'))

# saves an HTML file to the directory - open the file to view the plot
render.d3movie(net.dyn, usearrows = F,
               displaylabels = T, label=net %v% "labels", label.cex = .7,
               bg="#ffffff", vertex.border="#333333",
               vertex.cex = log(degree(net)+1)/2.5,
               vertex.col = net.dyn %v% "col",
               edge.lwd = (net.dyn %e% "width")/3,
               edge.col = '#55555599',
               vertex.tooltip = paste("<b>Name:</b>", (net.dyn %v% "name") , "<br>",
                                      "<b>National affiliation:</b>", (net.dyn %v% "country.name")),
               edge.tooltip = paste("<b>Connection:</b>", (net.dyn %e% "description")),
               launchBrowser=T, filename="replication-dynamic-updated.html",
               render.par=list(tween.frames = 30, show.time = F),
               plot.par=list(mar=c(0,0,0,0)), 
               d3.options = list(animateOnLoad = TRUE), output.mode='HTML')

##### STATIC PLOTS ######

### Install/load packages:
library(visNetwork)
library(dplyr)

### Import data
nodesstat <- import("nodes-stat.csv")
linksstat <- import("links-stat.csv")

# sort name for drop down menu
nodesstat <- arrange(nodesstat, id)

### Plot
set.seed(1)
plot.draft <- visNetwork(nodesstat, linksstat, height = "1300px", width = "1300px") %>% visLayout(randomSeed = 12)  %>% 
  visNodes(size = 8, font = list(size = 30, align = "left"), color = list(hover = "yellow"),
           scaling = list(min=10, max=60)) %>%
  visEdges(arrows =list(to = list(enabled = TRUE, scaleFactor = .5))) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visIgraphLayout(layout = "layout_with_lgl") %>%
  visGroups(groupname = "russia", color = "lightcoral", shape = "dot") %>%
  visGroups(groupname = "united states", color = "lightblue", shape = "dot") %>%
  visGroups(groupname ="other countries", color = "grey", shape = "dot") %>%
  visLegend(addNodes = list(list(label = "person", shape = "dot", color = "lightgrey"), 
                            list(label = "corporation", shape = "square", color = "lightgrey"),
                            list(label = "gov institution", shape = "triangle", color = "lightgrey")),
            width = 0.1, position = "left")

visSave(plot.draft, file = "replication-static.html")


#### STATIC PLOTS BY YEAR ####

edges.plot <- import("links-stat+years.csv")
nodes.plot <- nodesstat

## 1990
edges.plot.1990 <- subset(edges.plot, year <= 1990, select = c(from,to,title,width,smooth,length,arrows))
edges.1990.names <- unique(c(edges.plot.1990$from, edges.plot.1990$to))
nodes.plot.1990 <- subset(nodes.plot, id %in% edges.1990.names)

set.seed(1)
plot.draft.1990 <- visNetwork(nodes.plot.1990, edges.plot.1990, height = "700px", width = "700px") %>% visLayout(randomSeed = 12)  %>% 
  visNodes(size = 8, font = list(size = 30, align = "left"), color = list(hover = "yellow"),
           scaling = list(min=10, max=60)) %>%
  visEdges(arrows =list(to = list(enabled = TRUE, scaleFactor = .5))) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visIgraphLayout(layout = "layout_with_fr") %>%
  visGroups(groupname = "russia", color = "lightcoral", shape = "dot") %>%
  visGroups(groupname = "united states", color = "lightblue", shape = "dot") %>%
  visGroups(groupname ="other countries", color = "grey", shape = "dot") %>%
  visLegend(addNodes = list(list(label = "person", shape = "dot", color = "lightgrey"), 
                            list(label = "corporation", shape = "square", color = "lightgrey"),
                            list(label = "gov institution", shape = "triangle", color = "lightgrey")),
            width = 0.1, position = "left")

visSave(plot.draft.1990, file = "stat-plot-1990.html")

## 2000
edges.plot.2000 <- subset(edges.plot, year <= 2000, select = c(from,to,title,width,smooth,length,arrows))
edges.2000.names <- unique(c(edges.plot.2000$from, edges.plot.2000$to))
nodes.plot.2000 <- subset(nodes.plot, id %in% edges.2000.names)

set.seed(1)
plot.draft.2000 <- visNetwork(nodes.plot.2000, edges.plot.2000, height = "1000px", width = "1000px") %>% visLayout(randomSeed = 12)  %>% 
  visNodes(size = 8, font = list(size = 30, align = "left"), color = list(hover = "yellow"),
           scaling = list(min=10, max=60)) %>%
  visEdges(arrows =list(to = list(enabled = TRUE, scaleFactor = .5))) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visIgraphLayout(layout = "layout_with_fr") %>%
  visGroups(groupname = "russia", color = "lightcoral", shape = "dot") %>%
  visGroups(groupname = "united states", color = "lightblue", shape = "dot") %>%
  visGroups(groupname ="other countries", color = "grey", shape = "dot") %>%
  visLegend(addNodes = list(list(label = "person", shape = "dot", color = "lightgrey"), 
                            list(label = "corporation", shape = "square", color = "lightgrey"),
                            list(label = "gov institution", shape = "triangle", color = "lightgrey")),
            width = 0.1, position = "left")

visSave(plot.draft.2000, file = "stat-plot-2000.html")

## 2005
edges.plot.2005 <- subset(edges.plot, year <= 2005, select = c(from,to,title,width,smooth,length,arrows))
edges.2005.names <- unique(c(edges.plot.2005$from, edges.plot.2005$to))
nodes.plot.2005 <- subset(nodes.plot, id %in% edges.2005.names)

set.seed(1)
plot.draft.2005 <- visNetwork(nodes.plot.2005, edges.plot.2005, height = "1000px", width = "1000px") %>% visLayout(randomSeed = 12)  %>% 
  visNodes(size = 8, font = list(size = 30, align = "left"), color = list(hover = "yellow"),
           scaling = list(min=10, max=60)) %>%
  visEdges(arrows =list(to = list(enabled = TRUE, scaleFactor = .5))) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visIgraphLayout(layout = "layout_with_fr") %>%
  visGroups(groupname = "russia", color = "lightcoral", shape = "dot") %>%
  visGroups(groupname = "united states", color = "lightblue", shape = "dot") %>%
  visGroups(groupname ="other countries", color = "grey", shape = "dot") %>%
  visLegend(addNodes = list(list(label = "person", shape = "dot", color = "lightgrey"), 
                            list(label = "corporation", shape = "square", color = "lightgrey"),
                            list(label = "gov institution", shape = "triangle", color = "lightgrey")),
            width = 0.1, position = "left")

visSave(plot.draft.2005, file = "stat-plot-2005.html")


## 2010
edges.plot.2010 <- subset(edges.plot, year <= 2010, select = c(from,to,title,width,smooth,length,arrows))
edges.2010.names <- unique(c(edges.plot.2010$from, edges.plot.2010$to))
nodes.plot.2010 <- subset(nodes.plot, id %in% edges.2010.names)

set.seed(1)
plot.draft.2010 <- visNetwork(nodes.plot.2010, edges.plot.2010, height = "1300px", width = "1300px") %>% visLayout(randomSeed = 12)  %>% 
  visNodes(size = 8, font = list(size = 30, align = "left"), color = list(hover = "yellow"),
           scaling = list(min=10, max=60)) %>%
  visEdges(arrows =list(to = list(enabled = TRUE, scaleFactor = .5))) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visIgraphLayout(layout = "layout_with_fr") %>%
  visGroups(groupname = "russia", color = "lightcoral", shape = "dot") %>%
  visGroups(groupname = "united states", color = "lightblue", shape = "dot") %>%
  visGroups(groupname ="other countries", color = "grey", shape = "dot") %>%
  visLegend(addNodes = list(list(label = "person", shape = "dot", color = "lightgrey"), 
                            list(label = "corporation", shape = "square", color = "lightgrey"),
                            list(label = "gov institution", shape = "triangle", color = "lightgrey")),
            width = 0.1, position = "left")

visSave(plot.draft.2010, file = "stat-plot-2010.html")